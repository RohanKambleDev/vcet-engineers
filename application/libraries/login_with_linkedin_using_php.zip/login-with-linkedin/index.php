<title>Demo of Login with LinkedIn using PHP and LinkedIn oAuth API</title>
<h1 style="padding:25px; font-size:25px;">Login with LinkedIn using PHP</h1>
<?php
session_start();
error_reporting(0);
if(($_GET['login']=='linkedin') && ($_SESSION['login']=='1'))
{

include_once("config.php");
include_once("library/http.php");
include_once("library/oauth_client.php");


$client = new oauth_client_class;

$client->debug = false;
$client->debug_http = true;
$client->redirect_uri = $callbackURL;

$client->client_id = $linkedinApiKey;
$application_line = __LINE__;
$client->client_secret = $linkedinApiSecret;
$_SESSION['requestToken'] = serialize($client->client_secret);

/* API permissions
 */
$client->scope = $linkedinScope;
if (($success = $client->Initialize())) {
  if (($success = $client->Process())) {
    if (strlen($client->authorization_error)) {
      $client->error = $client->authorization_error;
      $success = false;
    } elseif (strlen($client->access_token)) {
      $success = $client->CallAPI(
					'http://api.linkedin.com/v1/people/~:(id,email-address,first-name,last-name,location,picture-url,public-profile-url,formatted-name)', 
					'GET', array(
						'format'=>'json'
					), array('FailOnAccessError'=>true), $user);
    }
  }
  $success = $client->Finalize($success);
}
if ($client->exit) exit;
if ($success) {

	            $result = '<h1>Linkedin Profile Details </h1>';
				$result .= '<img src="'.$user->pictureUrl.'">';
				$result .= '<br/>LinkedIn ID : ' . $user->id;
				$result .= '<br/>Email  : ' . $user->emailAddress;
				$result .= '<br/>Name : ' . $user->firstName.' '.$user->lastName;
				$result .= '<br/>Location : ' . $user->location->name;
				$result .= '<br/>Logout from <a href="logout.php">LinkedIn</a>';
                echo '<div>'.$result.'</div>';
				

} else {
 	 $_SESSION["err_msg"] = $client->error;
}
}else{
	

	echo '<a href="index.php?login=linkedin"><img src="linkedin.png" /></a>';
	$_SESSION['login'] = '1';
	
}
?>
